<?php
require "inc/functions.php";
require "inc/global.php";

require "controller/usuario.php";

require "view/_header.php";
require "view/_top.php";
require "view/usuarios.php";
require "view/_footer.php";
